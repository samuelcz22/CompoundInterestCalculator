import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    Prompter prompt = new Prompter();
    
    prompt.promptForInterest();

    while(!input.hasNextDouble() ){
      input.next();
      System.out.println("Please enter a valid number");
    }
    double interest = input.nextDouble();
    
    
    prompt.promptForPrincipal();
    while(!input.hasNextDouble()){
      input.next();
      System.out.println("Please enter a valid number");
    }
    double principal = input.nextDouble();

    prompt.promptForPeriods();
    while(!input.hasNextInt()){
      input.next();
      System.out.println("Please enter a valid number");
    }
    
    int periods = input.nextInt();
   
   
   
   
   
    CompoundInterest compInt = new CompoundInterest(principal,interest,periods);
    System.out.println(compInt);
  }
}