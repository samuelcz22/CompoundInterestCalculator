import java.lang.Math;


public class CompoundInterest{
private double principle;
private double interest;
private int numberOfCompoundingPeriods;
private double totalInterest;



/*
default constructor
pre: none
post: default object is made
*/
public CompoundInterest(double principle, double interest, int numberOfCompoundingPeriods) {
  this.principle = principle;
  this.interest = interest;
  this.numberOfCompoundingPeriods = numberOfCompoundingPeriods;
}

private void setTotalInterest() {
  totalInterest  =  principle*(Math.pow((1+interest),numberOfCompoundingPeriods) - 1);
}


@Override
public String toString() {
  setTotalInterest();
  String interest = "" + totalInterest;

  return interest;
}
}