class Prompter{


  public Prompter() {

  }

  public void promptForInterest() {
    System.out.println("Please enter a value for interest");
  }

  public void promptForPrincipal() {
    System.out.println("Please enter a value for the pricipal value");
  }

  public void promptForPeriods() 
  {
    System.out.println("Please enter the amount of times you wish to compound");
  }
}